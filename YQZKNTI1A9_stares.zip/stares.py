n=5
for i in range(1,n+1):
    stares=i 
    space=4*(n-i)
    row="* "*stares+" "*space+("* ")*stares
    print(row)